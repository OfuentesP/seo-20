const fs = require('fs');

module.exports = function generarInformeUnificadoCompleto({ homeResult, sitemapMd, paginas, urls404, sitio, fecha }) {
  let md = `# 📊 Informe SEO Consolidado – ${sitio}\n\n`;
  md += `_Fecha: ${fecha}_\n\n---\n`;

  // 1. Análisis del Home
  md += `\n## 🏠 Análisis del Home\n\n`;
  if (homeResult && homeResult.lighthouse) {
    const seoScore = Math.round(homeResult.lighthouse.categories.seo.score * 100);
    md += `**Puntaje SEO (Lighthouse):** ${seoScore} / 100\n\n`;

    const issues = Object.values(homeResult.lighthouse.audits)
      .filter(a => a.score !== 1 && a.scoreDisplayMode !== 'notApplicable');
    if (issues.length > 0) {
      md += `### Problemas detectados:\n`;
      for (const item of issues) {
        md += `- ${item.title} (${item.score !== null ? Math.round(item.score * 100) : 'N/A'})\n`;
      }
    }
  }

  if (homeResult && homeResult.scraping) {
    const palabras = homeResult.scraping.split(/\s+/).filter(w => w.length > 3);
    const topWords = {};
    palabras.forEach(p => topWords[p] = (topWords[p] || 0) + 1);
    const top = Object.entries(topWords).sort((a, b) => b[1] - a[1]).slice(0, 10);
    md += `\n**Top palabras visibles del Home:** ${top.map(w => w[0]).join(', ')}\n`;
  }

  // 2. Informe del sitemap
  md += `\n---\n\n## 🗺️ Revisión del Sitemap\n\n`;
  md += sitemapMd || '❌ No disponible';

  // 3. Análisis de páginas individuales
  md += `\n---\n\n## 📄 Análisis de Páginas por Sitemap\n\n`;
  paginas.forEach((p, i) => {
    md += `\n### ${i + 1}. ${p.url}\n`;
    if (p.lighthouse) {
      const score = Math.round(p.lighthouse.categories.seo.score * 100);
      md += `- Puntaje SEO: ${score} / 100\n`;
    }
    if (p.texto) {
      const palabras = p.texto.split(/\s+/).filter(w => w.length > 3);
      const topWords = {};
      palabras.forEach(p => topWords[p] = (topWords[p] || 0) + 1);
      const top = Object.entries(topWords).sort((a, b) => b[1] - a[1]).slice(0, 5);
      md += `- Palabras clave visibles: ${top.map(w => w[0]).join(', ')}\n`;
    }
  });

  // 4. URLs con error
  if (urls404 && urls404.length > 0) {
    md += `\n---\n\n## ⚠️ URLs con Error 404\n\n`;
    urls404.forEach(u => {
      md += `- ${u}\n`;
    });
  }

  return md;
};