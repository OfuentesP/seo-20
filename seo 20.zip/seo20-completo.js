
const generarInformeUnificadoCompleto = require('./generar-informe-unificado');
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const prompt = require('prompt-sync')();
const scrape = require('./scrape-text');
const generatePdfFromMd = require('./utils/pdf-generator');
const extraerUrlsSitemap = require('./extraer-urls-sitemap');
const axios = require('axios');

async function analizarMultiplesUrls(urls, folderName) {
  const resultados = [];
  const urlsFallidas = [];

  for (let i = 0; i < urls.length; i++) {
    const currentUrl = urls[i];
    const nombreLimpio = currentUrl.replace(/^https?:\/\//, '').replace(/[^\w]/g, '-').slice(0, 80);
    const subfolder = path.join(folderName, `pagina-${i + 1}-${nombreLimpio}`);
    fs.mkdirSync(subfolder, { recursive: true });

    console.log(`\n📄 [${i + 1}/${urls.length}] Verificando: ${currentUrl}`);

    try {
      const head = await axios.head(currentUrl, { timeout: 8000 });
      if (head.status === 404) throw new Error('404');
    } catch (err) {
      console.warn(`❌ URL inválida o con error 404: ${currentUrl}`);
      urlsFallidas.push(currentUrl);
      continue;
    }

    try {
      execSync(`lighthouse ${currentUrl} --output json --output-path=${path.join(subfolder, 'report.json')} --only-categories=seo --chrome-flags="--headless"`);
    } catch (err) {
      console.warn(`⚠️ Lighthouse falló en: ${currentUrl}`);
    }

    try {
      await scrape(currentUrl, path.join(subfolder, 'texto-visible.txt'));
    } catch (err) {
      console.warn(`⚠️ Scraping falló en: ${currentUrl}`);
    }

    resultados.push({ url: currentUrl, folder: subfolder });
  }

  return { exitosas: resultados, fallidas: urlsFallidas };
}

(async () => {
  const url = prompt('🔍 Ingresa la URL del sitio: ').trim();
  if (!url.startsWith('http')) {
    console.error('❌ URL inválida. Debe comenzar con http o https.');
    return;
  }

  const modo = prompt('🗺️ ¿Qué deseas analizar?\n1) Solo páginas principales\n2) Todas las URLs\n> ').trim();
  const urlsAAnalizar = await extraerUrlsSitemap(url, modo === '2' ? 'todas' : 'principales');

  if (urlsAAnalizar.length === 0) {
    console.error('❌ No se encontraron URLs válidas en el sitemap.');
    return;
  }

  const cleanDomain = url.replace(/^https?:\/\//, '').replace(/\/$/, '').replace(/[/:]/g, '-');
  const folderName = `resultados/${new Date().toISOString().slice(0, 10)}-${cleanDomain}`;
  fs.mkdirSync(folderName, { recursive: true });

  const { exitosas, fallidas } = await analizarMultiplesUrls(urlsAAnalizar, folderName);

  const sitemapMdString = `Se analizaron ${urlsAAnalizar.length} URLs desde el sitemap de ${url}.`;

  const informeFinal = await generarInformeUnificadoCompleto({
    url,
    fecha: new Date().toISOString().slice(0, 10),
    home: {
      report: path.join(folderName, 'report.json'),
      texto: path.join(folderName, 'texto-visible.txt')
    },
    sitemapMd: sitemapMdString,
    paginas: exitosas,
    urlsFallidas: fallidas
  });

  const mdFinalPath = path.join(folderName, 'informe-seo-final.md');
  fs.writeFileSync(mdFinalPath, informeFinal);
  await generatePdfFromMd(mdFinalPath, path.join(folderName, 'informe-seo-final.pdf'));
  fs.unlinkSync(mdFinalPath);

  console.log(`\n✅ Informe generado: ${path.join(folderName, 'informe-seo-final.pdf')}`);
})();
