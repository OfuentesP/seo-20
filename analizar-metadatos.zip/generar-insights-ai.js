require('dotenv').config();
const { GoogleGenerativeAI } = require('@google/generative-ai');

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

module.exports = async function generarInsightsIA({ lighthouse, scraping }) {
  if (!process.env.GEMINI_API_KEY) {
    console.warn('⚠️ GEMINI_API_KEY no definido en .env');
    return '❌ No se pudo generar recomendaciones automáticas con IA.';
  }

  try {
    const model = genAI.getGenerativeModel({ model: 'gemini-pro' });

    const prompt = `
Eres un experto en SEO y experiencia de usuario. A partir de la siguiente información, analiza el sitio y sugiere mejoras específicas tanto para el equipo técnico como para el negocio. Responde en español, sin rodeos, en un formato claro.

### Datos de Lighthouse:
${JSON.stringify(lighthouse.categories, null, 2)}

### Texto visible en el home:
${scraping.slice(0, 2000)}

Devuelve recomendaciones con esta estructura:

## Análisis de SEO, UX y Accesibilidad

**Problemas detectados:**
1. ...
2. ...

**Recomendaciones para el equipo técnico:**
1. ...
2. ...

**Recomendaciones orientadas al negocio:**
1. ...
2. ...
    `.trim();

    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();

    return text;
  } catch (err) {
    console.error('❌ Error al generar recomendaciones IA:', err.message);
    return '❌ No se pudieron generar recomendaciones automáticas con IA.';
  }
};
