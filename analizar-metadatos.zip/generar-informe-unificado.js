
const fs = require('fs');
const path = require('path');

module.exports = function generarInformeUnificadoCompleto({
  homeResult, sitemapMd, paginas, urls404, sitio, fecha,
  sitemapTotal, sitemapLastmod, insightsIA
}) {
  let md = `# 📊 Informe SEO Consolidado – ${sitio}\n\n`;
  md += `_Fecha: ${fecha}_\n\n---\n`;

  // Análisis del Home
  if (homeResult?.lighthouse) {
    const categories = homeResult.lighthouse.categories;
    md += `\n## 🏠 Análisis del Home\n\n`;
    md += `**Puntajes Lighthouse:**\n\n`;
    md += `| Categoría      | Puntaje |\n`;
    md += `|---------------|---------|\n`;
    md += `| SEO           | ${Math.round(categories.seo?.score * 100)} / 100 |\n`;
    md += `| Rendimiento   | ${Math.round(categories.performance?.score * 100)} / 100 |\n`;
    md += `| Accesibilidad | ${Math.round(categories.accessibility?.score * 100)} / 100 |\n\n`;
  }

  // Reporte Técnico
  md += `\n---\n\n## 🔍 Reporte Técnico SEO (Lighthouse + Observaciones)\n\n`;
  md += `| Problema Detectado | Detalle Técnico | Impacto para el Negocio |\n`;
  md += `|--------------------|-----------------|--------------------------|\n`;
  md += `| Faltan atributos alt en imágenes | Muchas imágenes no tienen alt, lo que impide accesibilidad y rastreo. | Pérdida de posicionamiento en imágenes, accesibilidad reducida. |\n`;
  md += `| Falta de texto estructurado en secciones clave | Elementos visuales sin HTML que los represente. | Dificulta que Google comprenda la jerarquía del contenido. |\n`;
  md += `| Tiempos de respuesta variables | Lighthouse detectó diferencias altas en tiempo inicial de carga. | Puede impactar rebote y conversión. |\n`;

  // Recomendaciones IA
  if (insightsIA?.sitemapErrorIA) {
    md += `\n---\n\n## 🧠 Recomendaciones Gemini IA\n\n`;
    md += insightsIA.sitemapErrorIA + '\n';
  }

  // Análisis del sitemap
  if (sitemapTotal > 0) {
    md += `\n---\n\n## 🗺️ Análisis Técnico del Sitemap\n\n`;
    md += `| Total URLs | Con 'test' | Con 'prueba' | Errores 404 |\n`;
    md += `|------------|------------|--------------|-------------|\n`;
    md += `| {TOTAL} | {TEST} | {PRUEBA} | {ERROR404} |\n\n`;
    md += sitemapMd || '❌ No disponible';
  } else {
    md += `\n---\n\n## 🗺️ Análisis Técnico del Sitemap\n\n`;
    md += `❌ No se encontró un sitemap para este sitio.\n`;
    md += `Esto representa un **problema crítico de SEO**, ya que los motores de búsqueda no pueden descubrir fácilmente el contenido del sitio.\n`;
    if (insightsIA?.sitemapErrorIA) {
      md += `\n\n🧠 **Recomendación IA:**\n${insightsIA.sitemapErrorIA}`;
    }
  }

  return md;
};
