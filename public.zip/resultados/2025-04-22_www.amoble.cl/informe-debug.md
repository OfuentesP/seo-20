# Informe SEO

**URL:** https://www.amoble.cl
**Fecha:** 2025-04-23

## Análisis del Home
### Texto visible del home (scraping)
No se pudo extraer contenido visible del home o el archivo estaba vacío.

