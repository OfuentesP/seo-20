# Informe SEO

**URL:** https://comercializadoraroca.cl/
**Fecha:** 2025-04-23

## Análisis del Home
### Texto visible del home (scraping)
No se pudo extraer contenido visible del home o el archivo estaba vacío.

### Puntajes Lighthouse

| Categoría      | Puntaje     |
|----------------|-------------|
| SEO | No disponible |
| Rendimiento | 89 / 100 |
| Accesibilidad | No disponible |




## Diagnóstico Técnico SEO y Recomendaciones

### 1. Core Web Vitals
**Largest Contentful Paint (LCP):** 2.9 s (score: 0.82)
**Cumulative Layout Shift (CLS):** 0.01 (score: 1)
**Total Blocking Time (TBT):** 270 ms (score: 0.82)

### 2. Optimización de Imágenes
No se detectaron problemas relevantes con las imágenes.

### 3. Políticas de Caché
Se detectaron 11 recursos sin caché eficiente.
**Recomendación:** Usar Cache-Control con expiración.

### 4. Carga y ejecución de JS
Evaluación de scripts JS: 944 ms
Tiempo en layout/render: 0 ms
**Recomendación:** Code splitting, reducir dependencias JS, priorizar contenido.

### 5. Scripts de Terceros
Se cargan más de 5 scripts de terceros. Considerar uso de async/defer y evaluar impacto en UX y SEO.

---
Este diagnóstico fue generado automáticamente a partir del análisis Lighthouse (PageSpeed API).