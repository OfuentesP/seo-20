# Informe SEO

**URL:** https://m.aguasandinas.cl/
**Fecha:** 2025-04-23

## Análisis del Home
### Texto visible del home (scraping)
No se pudo extraer contenido visible del home o el archivo estaba vacío.

### Puntajes Lighthouse

| Categoría      | Puntaje     |
|----------------|-------------|
| SEO | No disponible |
| Rendimiento | 32 / 100 |
| Accesibilidad | No disponible |


