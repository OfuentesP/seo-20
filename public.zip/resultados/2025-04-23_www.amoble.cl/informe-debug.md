# Informe SEO

**URL:** https://www.amoble.cl
**Fecha:** 2025-04-23

## Análisis del Home
### Texto visible del home (scraping)
No se pudo extraer contenido visible del home o el archivo estaba vacío.

### Puntajes Lighthouse

| Categoría      | Puntaje     |
|----------------|-------------|
| SEO | No disponible |
| Rendimiento | 54 / 100 |
| Accesibilidad | No disponible |






## 🧠 Diagnóstico Técnico SEO y Recomendaciones

### 🔍 1. Core Web Vitals
| Métrica | Valor | Score |
|---------|-------|--------|
| LCP     | 24.5 s | 0 |
| CLS     | 0 | 1 |
| TBT     | 170 ms | 0.92 |

### 🖼️ 2. Optimización de Imágenes
❌ Se detectó un ahorro potencial de **2795 KB** por falta de compresión o formatos modernos.

**✅ Recomendación:** Usar WebP, compresión eficiente y responsive srcset/sizes.

### 🗂️ 3. Políticas de Caché
❌ Hay **57 recursos** sin política de caché eficiente.

**✅ Recomendación:** Usar encabezados Cache-Control con expiración.

### ⚙️ 4. Carga y ejecución de JavaScript
- Evaluación de scripts JS: **1022 ms**
- Tiempo en layout/render: **0 ms**

**✅ Recomendación:** Reducir dependencias, aplicar code splitting, priorizar carga útil.

### 🎯 5. Scripts de Terceros
❌ Se cargan más de **5 scripts** de terceros. Esto puede afectar rendimiento y SEO.

**✅ Recomendación:** Usar `async` o `defer`, y eliminar lo no crítico.

---
📝 *Este análisis fue generado automáticamente a partir del JSON de Lighthouse (PageSpeed API).*