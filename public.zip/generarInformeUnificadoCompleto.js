const fs = require('fs');
const path = require('path');

async function generarInformeUnificadoCompleto({ url, textoScraping, lighthouse }) {
  const fecha = new Date().toISOString().split('T')[0];
  const dominio = new URL(url).hostname.replace(/^www\./, '');
  const carpeta = path.join(__dirname, 'resultados', `${fecha}_${dominio}`);

  const homeResult = [];

  // 🔹 Scraping
  if (textoScraping && textoScraping.length > 0) {
    homeResult.push({
      titulo: 'Texto visible del home (scraping)',
      contenido: textoScraping.length > 1000 ? textoScraping.slice(0, 1000) + ' [...]' : textoScraping
    });
  } else {
    homeResult.push({
      titulo: 'Texto visible del home (scraping)',
      contenido: 'No se pudo extraer contenido visible del home o el archivo estaba vacío.'
    });
  }

  // 🔹 Metadata (opcional)
  const metadataPath = path.join(carpeta, 'metadata.json');
  if (fs.existsSync(metadataPath)) {
    const metadata = JSON.parse(fs.readFileSync(metadataPath, 'utf-8'));
    homeResult.push({
      titulo: 'Metadatos',
      contenido: JSON.stringify(metadata, null, 2)
    });
  }

  // 🔹 Puntajes Lighthouse (pasados como parámetro)
  if (lighthouse && lighthouse.categories) {
    const seo = lighthouse.categories?.seo?.score ?? null;
    const performance = lighthouse.categories?.performance?.score ?? null;
    const accessibility = lighthouse.categories?.accessibility?.score ?? null;

    const puntajes = [
      { categoria: 'SEO', valor: seo !== null ? `${seo * 100} / 100` : 'No disponible' },
      { categoria: 'Rendimiento', valor: performance !== null ? `${performance * 100} / 100` : 'No disponible' },
      { categoria: 'Accesibilidad', valor: accessibility !== null ? `${accessibility * 100} / 100` : 'No disponible' }
    ];

    const tablaMarkdown = `
| Categoría      | Puntaje     |
|----------------|-------------|
${puntajes.map(p => `| ${p.categoria} | ${p.valor} |`).join('\n')}
`;

    homeResult.push({
      titulo: 'Puntajes Lighthouse',
      contenido: tablaMarkdown
    });
  }

  // ---------- CONSTRUCCIÓN DEL INFORME ----------
  let markdown = `# Informe SEO\n\n`;
  markdown += `**URL:** ${url}\n`;
  markdown += `**Fecha:** ${fecha}\n\n`;

  markdown += `## Análisis del Home\n`;
  homeResult.forEach(bloque => {
    markdown += `### ${bloque.titulo}\n`;
    markdown += `${bloque.contenido}\n\n`;
  });

  // 🔧 Limpieza final para evitar errores en markdown-pdf
  markdown = markdown.replace(/\((undefined|null|about:blank|javascript:void\(0\))\)/gi, '(#)');
  markdown = markdown.replace(/\]\(([^)]+)\)/g, (match) => {
    const url = match.slice(2, -1);
    try {
      new URL(url);
      return match;
    } catch {
      return '](#)';
    }
  });

  return markdown;
}

module.exports = {
  generarInformeUnificadoCompleto
};
