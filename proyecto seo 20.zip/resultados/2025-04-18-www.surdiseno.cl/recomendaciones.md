
# 🧠 Recomendaciones SEO para: https://www.surdiseno.cl/

_Fecha de análisis: 2025-04-18_

---

## 🧩 Recomendaciones SEO por zonas visuales

| Zona visual         | Qué se muestra (visual)                          | ¿Está en el texto visible/HTML? | Oportunidades SEO                                                                 |
|---------------------|--------------------------------------------------|-------------------------------|------------------------------------------------------------------------------------|
| Hero / Banner       | Imagen con frase “New Arrivals”                 | ❌                             | Agregar `<h1>` y descripción con keywords relevantes + CTA con texto ancla útil   |
| Categoría destacada | Productos como “Silla oficina Vivid”, etc.      | ✅ parcial                     | Incluir encabezado semántico `<h2>` + texto descriptivo con intención de búsqueda |
| Carrusel de ofertas | Ofertas con % de descuento                      | ❌                             | Añadir texto HTML debajo con características destacadas, títulos visibles         |
| Marcas destacadas   | Logos e imágenes de Tempur, Kare                | ❌                             | Añadir texto HTML con descripción y enlaces a landing SEO específicas             |
| Footer / Tiendas    | Imágenes de tiendas físicas                     | ❌                             | Añadir nombre, dirección y schema.org `LocalBusiness` para SEO local              |
