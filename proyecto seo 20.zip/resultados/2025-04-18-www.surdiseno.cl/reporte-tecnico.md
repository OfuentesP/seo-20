# 🧪 Informe Técnico SEO – https://www.surdiseno.cl/

_Fecha: 2025-04-18_

---

## Resumen de categorías Lighthouse

| Categoría         | Puntaje |
|-------------------|---------|
| SEO | N/A |

---

## Principales problemas y oportunidades de mejora

### 🔧 Image elements do not have `[alt]` attributes (0/100)
- **Explicación técnica:** Informative elements should aim for short, descriptive alternate text. Decorative elements can be ignored with an empty alt attribute. [Learn more about the `alt` attribute](https://dequeuniversity.com/rules/axe/4.10/image-alt).
- **Explicación no técnica:** Este punto afecta el rendimiento, la visibilidad o la accesibilidad del sitio.

### 🔧 Links are not crawlable (0/100)
- **Explicación técnica:** Search engines may use `href` attributes on links to crawl websites. Ensure that the `href` attribute of anchor elements links to an appropriate destination, so more pages of the site can be discovered. [Learn how to make links crawlable](https://support.google.com/webmasters/answer/9112205)
- **Explicación no técnica:** Este punto afecta el rendimiento, la visibilidad o la accesibilidad del sitio.

### 🔧 Structured data is valid (N/A/100)
- **Explicación técnica:** Run the [Structured Data Testing Tool](https://search.google.com/structured-data/testing-tool/) and the [Structured Data Linter](http://linter.structured-data.org/) to validate structured data. [Learn more about Structured Data](https://developer.chrome.com/docs/lighthouse/seo/structured-data/).
- **Explicación no técnica:** Este punto afecta el rendimiento, la visibilidad o la accesibilidad del sitio.
